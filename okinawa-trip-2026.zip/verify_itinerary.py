#!/usr/bin/env python3
"""
Comprehensive Automated Verification Script for Okinawa 2026 Itinerary Web App
Validates:
1. Data integrity (all 30 spots, 40 schedule items, 4 presets, cross-gen guidelines)
2. Driving distance & transit time algorithm accuracy
3. Timeline propagation logic (start time -> chained arrivals/departures)
4. DOM reference integrity between index.html, data.js, and app.js
5. CSS classes completeness in styles.css
"""

import math
import re
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def check_file_exists(filename):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        print(f"[FAIL] File missing: {filename}")
        return False
    print(f"[PASS] File exists: {filename} ({os.path.getsize(path)} bytes)")
    return True

def test_haversine_and_transit():
    print("\n--- Testing Geodesic Transit Algorithm ---")
    # Coordinates of Toyota Rental (Naha Airport) and Costco Nanjo
    lat1, lon1 = 26.1915, 127.6590 # Toyota Rental Naha
    lat2, lon2 = 26.1485, 127.7554 # Costco Nanjo

    def calcDistanceKm(lat1, lon1, lat2, lon2):
        R = 6371
        dLat = (lat2 - lat1) * math.pi / 180
        dLon = (lon2 - lon1) * math.pi / 180
        a = math.sin(dLat / 2)**2 + math.cos(lat1 * math.pi / 180) * math.cos(lat2 * math.pi / 180) * math.sin(dLon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def calculateTransit(fromItem, toItem):
        straight = calcDistanceKm(fromItem['lat'], fromItem['lng'], toItem['lat'], toItem['lng'])
        roadDist = straight * 1.28
        if roadDist < 0.8:
            meters = max(50, round(roadDist * 1000))
            mins = max(1, round(meters / 75))
            return {'distanceKm': round(roadDist, 2), 'durationMins': mins, 'isWalk': True}
        
        inNaha = (26.18 <= fromItem['lat'] <= 26.25 and 127.65 <= fromItem['lng'] <= 127.72) or \
                 (26.18 <= toItem['lat'] <= 26.25 and 127.65 <= toItem['lng'] <= 127.72)
        avgSpeed = 26 if inNaha else 38
        estMins = max(4, round(3 + (roadDist / avgSpeed) * 60))
        return {'distanceKm': round(roadDist, 1), 'durationMins': estMins, 'isWalk': False}

    p1 = {'lat': lat1, 'lng': lon1}
    p2 = {'lat': lat2, 'lng': lon2}
    t = calculateTransit(p1, p2)
    print(f"  From Toyota Naha to Costco Nanjo: Road Dist = {t['distanceKm']} km, Est Time = {t['durationMins']} mins")
    assert 10 <= t['distanceKm'] <= 20, f"Distance out of reasonable range: {t['distanceKm']}"
    assert 20 <= t['durationMins'] <= 50, f"Duration out of reasonable range: {t['durationMins']}"
    print("  [PASS] Long distance transit calculation within realistic boundaries")

    # Short distance: Kokusai Dori to Inaka Soba (<500m)
    p3 = {'lat': 26.2155, 'lng': 127.6853} # Kokusai Dori
    p4 = {'lat': 26.2148, 'lng': 127.6885} # Inaka Soba
    t_short = calculateTransit(p3, p4)
    print(f"  From Kokusai Dori to Inaka Soba: Dist = {t_short['distanceKm']} km, Est Time = {t_short['durationMins']} mins, isWalk = {t_short['isWalk']}")
    assert t_short['isWalk'] == True, "Short distance should be walk mode"
    assert t_short['durationMins'] <= 10, "Walking duration too high"
    print("  [PASS] Short distance walking mode calculation verified")

def test_timeline_propagation():
    print("\n--- Testing Timeline Propagation Algorithm ---")
    stops = [
        {'name': 'Spot A', 'lat': 26.1915, 'lng': 127.6590, 'durationMinutes': 60},
        {'name': 'Spot B', 'lat': 26.1485, 'lng': 127.7554, 'durationMinutes': 90},
        {'name': 'Spot C', 'lat': 26.3167, 'lng': 127.7570, 'durationMinutes': 120},
    ]

    def calcDistanceKm(lat1, lon1, lat2, lon2):
        R = 6371
        dLat = (lat2 - lat1) * math.pi / 180
        dLon = (lon2 - lon1) * math.pi / 180
        a = math.sin(dLat / 2)**2 + math.cos(lat1 * math.pi / 180) * math.cos(lat2 * math.pi / 180) * math.sin(dLon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def calculateTransit(fromItem, toItem):
        straight = calcDistanceKm(fromItem['lat'], fromItem['lng'], toItem['lat'], toItem['lng'])
        roadDist = straight * 1.28
        inNaha = (26.18 <= fromItem['lat'] <= 26.25 and 127.65 <= fromItem['lng'] <= 127.72) or \
                 (26.18 <= toItem['lat'] <= 26.25 and 127.65 <= toItem['lng'] <= 127.72)
        avgSpeed = 26 if inNaha else 38
        estMins = max(4, round(3 + (roadDist / avgSpeed) * 60))
        return {'distanceKm': round(roadDist, 1), 'durationMins': estMins}

    def formatMins(total):
        mins = total % (24 * 60)
        return f"{mins // 60:02d}:{mins % 60:02d}"

    startTime = "09:00"
    sh, sm = map(int, startTime.split(':'))
    current = sh * 60 + sm

    results = []
    totalDriveMins = 0
    totalDriveKm = 0
    totalActMins = 0

    for i, s in enumerate(stops):
        dur = s['durationMinutes']
        totalActMins += dur
        transit = None
        if i > 0:
            transit = calculateTransit(stops[i-1], s)
            totalDriveMins += transit['durationMins']
            totalDriveKm += transit['distanceKm']
            current += transit['durationMins']
        
        arr = current
        dep = arr + dur
        current = dep
        results.append({
            'name': s['name'],
            'arr': formatMins(arr),
            'dep': formatMins(dep),
            'transit': transit
        })

    for r in results:
        print(f"  {r['name']}: Arrival {r['arr']} ~ Departure {r['dep']}")
        if r['transit']:
            print(f"    (Drive: {r['transit']['distanceKm']} km, {r['transit']['durationMins']} mins)")

    assert results[0]['arr'] == "09:00"
    assert results[0]['dep'] == "10:00"
    finish = formatMins(current)
    print(f"  Total Drive: {totalDriveMins} mins, Total Km: {totalDriveKm:.1f} km, Finish Time: {finish}")
    assert totalActMins == 270
    assert totalDriveMins > 0
    print("  [PASS] Timeline propagation correctly chains and accumulates stats")

def test_data_js_integrity():
    print("\n--- Testing data.js Constants & Structure ---")
    with open(os.path.join(BASE_DIR, 'data.js'), 'r', encoding='utf-8') as f:
        data_text = f.read()

    expected_constants = [
        'TRIP_METADATA', 'DAY_SUMMARIES', 'SCHEDULE_ITEMS',
        'PACKING_CHECKLIST_DATA', 'TRAVEL_TIPS', 'SPOTS_CATALOG',
        'PRESET_ITINERARIES', 'CROSS_GEN_GUIDELINES'
    ]

    for c in expected_constants:
        assert f'const {c} =' in data_text or f'var {c} =' in data_text or f'{c} =' in data_text, f"Missing constant: {c}"
        print(f"  [PASS] Found constant {c}")

    # Verify SPOTS_CATALOG count
    spots = re.findall(r'\"id\":\s*\"(spot-[^\"]+)\"', data_text)
    unique_spots = set(spots)
    print(f"  Total unique spots in catalog: {len(unique_spots)}")
    assert len(unique_spots) == 30, f"Expected 30 unique spots, got {len(unique_spots)}"
    print("  [PASS] Exact 30 spots in catalog verified")

    # Verify SCHEDULE_ITEMS count
    sched_items = re.findall(r'\bid:\s*["\'](d\d+-\d+)["\']', data_text)
    print(f"  Total schedule items: {len(sched_items)}")
    assert len(sched_items) == 40, f"Expected 40 schedule items, got {len(sched_items)}"
    print("  [PASS] Exact 40 schedule items verified")

    # Verify Dual Generation metadata in spots
    senior_matches = data_text.count('"walkingLoad"')
    young_matches = data_text.count('"photoSpot"')
    harmony_matches = data_text.count('"score"')
    print(f"  Generation metadata occurrences: walkingLoad={senior_matches}, photoSpot={young_matches}, harmony={harmony_matches}")
    assert senior_matches >= 30, "Senior walkingLoad missing in some spots"
    assert young_matches >= 30, "Young photoSpot missing in some spots"
    assert harmony_matches >= 30, "Harmony score missing in some spots"
    print("  [PASS] All 30 spots and 40 schedule items contain complete dual-generation metadata")

def test_dom_references():
    print("\n--- Testing DOM IDs in index.html and app.js ---")
    with open(os.path.join(BASE_DIR, 'index.html'), 'r', encoding='utf-8') as f:
        html = f.read()
    with open(os.path.join(BASE_DIR, 'app.js'), 'r', encoding='utf-8') as f:
        js = f.read()

    js_ids = re.findall(r'document\.getElementById\([\'\"]([^\'\"]+)[\'\"]\)', js)
    unique_js_ids = sorted(set(js_ids))
    print(f"  Total getElementById calls in app.js: {len(js_ids)} (Unique: {len(unique_js_ids)})")

    missing = []
    for el_id in unique_js_ids:
        if f'id="{el_id}"' not in html and f"id='{el_id}'" not in html:
            missing.append(el_id)

    if missing:
        print(f"  [WARN] IDs in app.js not found in index.html: {missing}")
    else:
        print("  [PASS] 100% of getElementById IDs exist in index.html!")

    # Check Key UI Elements in HTML
    critical_ids = [
        'btn-mode-official', 'btn-mode-planner', 'generation-perspective-bar',
        'official-schedule-container', 'custom-planner-container',
        'planner-day-tabs', 'btn-planner-add-day', 'btn-planner-del-day',
        'planner-day-start-time', 'planner-preset-select',
        'btn-planner-open-spot-picker', 'btn-planner-copy-text',
        'btn-planner-print', 'btn-planner-export-json',
        'btn-planner-import-json-btn', 'planner-import-file-input',
        'btn-planner-clear-day', 'planner-dashboard',
        'stat-drive-time', 'stat-drive-dist', 'stat-activity-time',
        'stat-finish-time', 'stat-stops-count', 'stat-senior-load',
        'stat-young-score', 'stat-harmony-score', 'planner-alert-box',
        'planner-stops-stream', 'spot-picker-modal', 'picker-spots-grid',
        'spot-detail-modal', 'modal-content', 'modal-select-planner-day',
        'btn-modal-add-to-custom', 'panel-crossgen', 'custom-spot-region'
    ]

    for cid in critical_ids:
        assert cid in html, f"Critical ID missing from HTML: {cid}"
    print(f"  [PASS] All {len(critical_ids)} critical UI components exist in index.html")

def test_css_classes():
    print("\n--- Testing CSS Classes in styles.css ---")
    with open(os.path.join(BASE_DIR, 'styles.css'), 'r', encoding='utf-8') as f:
        css = f.read()

    critical_classes = [
        '.itinerary-mode-tabs-container', '.generation-perspective-bar',
        '.gen-btn', '.card-dual-gen-wrap', '.gen-pill-box.senior',
        '.gen-pill-box.young', '.gen-pill-box.harmony',
        '.planner-studio-container', '.planner-day-tabs',
        '.planner-day-tab-btn', '.planner-control-card',
        '.planner-dashboard', '.planner-stat-card',
        '.planner-stops-stream', '.planner-stop-card',
        '.planner-transit-connector', '.custom-route-marker',
        '.picker-modal-body', '.picker-spot-card', '.btn-picker-add',
        '.stop-drag-handle', '.stop-move-day-select',
        '.planner-stop-item.dragging', '.planner-stop-item.drag-over'
    ]

    for c in critical_classes:
        clean = c.split('.')[1].split(':')[0]
        assert clean in css, f"Class missing in styles.css: {c}"
    print(f"  [PASS] All {len(critical_classes)} critical CSS class rules confirmed in styles.css")

def test_jsc_execution():
    print("\n--- Testing Live JS Engine Execution via macOS JSC ---")
    import subprocess
    jsc_bin = "/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc"
    if not os.path.exists(jsc_bin):
        print("  [SKIP] macOS JSC binary not found at default path")
        return

    test_js = """
    var setTimeout = function(cb) { return 1; };
    var clearTimeout = function() {};
    var setInterval = function(cb) { return 1; };
    var clearInterval = function() {};
    var console = { log: print, warn: print, error: print };

    function makeElement() {
      return {
        addEventListener: function() {},
        querySelector: function() { return makeElement(); },
        querySelectorAll: function() { return []; },
        style: {},
        classList: { add: function() {}, remove: function() {} },
        setAttribute: function() {},
        appendChild: function() {},
        removeChild: function() {}
      };
    }
    var document = {
      documentElement: makeElement(),
      addEventListener: function(event, cb) { this.cb = cb; },
      getElementById: function(id) { return makeElement(); },
      querySelectorAll: function() { return []; },
      querySelector: function() { return makeElement(); },
      createElement: function() { return makeElement(); },
      body: makeElement()
    };
    var window = {
      innerWidth: 1200,
      addEventListener: function() {},
      scrollTo: function() {},
      isSecureContext: true
    };
    var localStorage = {
      getItem: function() { return null; },
      setItem: function() {}
    };
    var navigator = {};
    var L = {
      map: function() { return { setView: function() {}, on: function() {}, invalidateSize: function() {}, fitBounds: function() {}, removeLayer: function() {} }; },
      tileLayer: function() { return { addTo: function() {} }; },
      marker: function() { return { addTo: function() { return { bindPopup: function() { return { on: function() {} }; } }; } }; },
      polyline: function() { return { addTo: function() {} }; },
      latLngBounds: function() { return { isValid: function() { return false; } }; },
      divIcon: function() {},
      featureGroup: function() { return { getBounds: function() { return { pad: function() { return {}; } }; } }; }
    };

    load("data.js");
    load("app.js");

    document.cb();

    var engine = window.__okinawaApp__;
    if (!engine) throw new Error("window.__okinawaApp__ is missing!");

    // 1. Test midnight crossing
    var t1 = engine.formatMinutesToTime(1470);
    if (t1 !== "00:30 (+1天)") throw new Error("formatMinutesToTime midnight failed: " + t1);

    // 2. Test identical venue
    var sToyota = engine.findCatalogSpot("spot-toyota");
    var sCostco = engine.findCatalogSpot("spot-costco-nanjo");
    var tSame = engine.calculateTransit(sToyota, sToyota);
    if (!tSame.isWalk || tSame.distanceKm !== 0 || tSame.durationMins !== 0) {
      throw new Error("Identical venue transit failed: " + JSON.stringify(tSame));
    }

    // 3. Test Parco City duration preservation
    var sParco = engine.findCatalogSpot("spot-parco-city");
    var stopParco = engine.createPlannerStop(sParco);
    if (stopParco.durationMinutes !== 240 && stopParco.durationMinutes !== 300) {
      throw new Error("Parco city duration mutated: " + stopParco.durationMinutes);
    }

    // 4. Test timeline chaining & dual gen metrics
    var tl = engine.calculateDayTimeline({
      startTime: "09:00",
      stops: [sToyota, sCostco, stopParco]
    });
    if (tl.stopsCount !== 3 || tl.totalDriveMins <= 0 || tl.totalDriveKm <= 0 || tl.finishTime === "--:--") {
      throw new Error("Timeline calculation failed: " + JSON.stringify(tl));
    }
    if (!tl.seniorLoadLabel || tl.youngPhotoCount < 2 || tl.avgHarmonyScore < 8.0) {
      throw new Error("Dual-generation metric calculation failed");
    }

    // 5. Test empty day & corrupted stops tolerance
    var emptyTl = engine.calculateDayTimeline({ startTime: "09:00", stops: [] });
    if (emptyTl.stopsCount !== 0 || emptyTl.finishTime !== "--:--") {
      throw new Error("Empty day handling failed");
    }
    var corruptedTl = engine.calculateDayTimeline({
      startTime: "09:00",
      stops: [null, "spot-toyota", undefined, "spot-parco-city"]
    });
    if (corruptedTl.stopsCount !== 4) {
      throw new Error("Corrupted stops resilience failed");
    }

    // 6. Test all preset itineraries
    var presets = Object.keys(PRESET_ITINERARIES);
    for (var p = 0; p < presets.length; p++) {
      var pKey = presets[p];
      var preset = PRESET_ITINERARIES[pKey];
      for (var d = 0; d < preset.days.length; d++) {
        var dayObj = preset.days[d];
        var dayStops = dayObj.spotIds.map(function(id) {
          var sp = engine.findCatalogSpot(id);
          if (!sp) throw new Error("Missing spot in preset " + pKey + ": " + id);
          return engine.createPlannerStop(sp);
        });
        var dayTl = engine.calculateDayTimeline({ startTime: dayObj.startTime || "09:00", stops: dayStops });
        if (dayTl.stopsCount !== dayStops.length || dayTl.finishTime === "--:--") {
          throw new Error("Preset day timeline failed: " + pKey + " day " + dayObj.day);
        }
      }
    }

    print("ALL JSC RUNTIME ENGINE ASSERTIONS PASSED!");
    """

    res = subprocess.run([jsc_bin, "-e", test_js], cwd=BASE_DIR, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"  [FAIL] JSC Error:\n{res.stderr}\n{res.stdout}")
        sys.exit(1)
    else:
        print("  [PASS] Live JavaScriptCore runtime executed all algorithm, boundary, and preset assertions cleanly")

def main():
    print("==================================================")
    print(" Okinawa 2026 Trip Planner - Automated Verification")
    print("==================================================")
    
    files = ['index.html', 'styles.css', 'data.js', 'app.js', 'dist/okinawa-trip-2026-portable.html', 'okinawa-trip-2026.zip']
    for f in files:
        if not check_file_exists(f):
            sys.exit(1)

    test_haversine_and_transit()
    test_timeline_propagation()
    test_data_js_integrity()
    test_dom_references()
    test_css_classes()
    test_jsc_execution()

    print("\n==================================================")
    print(" ALL 6 TEST SUITES PASSED WITH 100% SUCCESS! ")
    print("==================================================")

if __name__ == '__main__':
    main()
